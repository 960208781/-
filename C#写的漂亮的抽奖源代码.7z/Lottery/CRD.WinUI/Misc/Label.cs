﻿using System;
using System.Collections.Generic;

using System.Text;

namespace CRD.WinUI.Misc
{
  public  class Label:System.Windows.Forms.Label
    {
      public Label()
          : base()
      {
          this.BackColor = System.Drawing.Color.Transparent;
      }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace CRD.WinUI.Forms
{
    public partial class EnterFrom1 : EnterUserControl 
    {
        public EnterFrom1()
        {
            InitializeComponent();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lottery
{
    public class Model
    {
        string _Nun;
        public string Nunber
        {
            set { _Nun = value; }
            get { return _Nun; }
        }
    }
}
